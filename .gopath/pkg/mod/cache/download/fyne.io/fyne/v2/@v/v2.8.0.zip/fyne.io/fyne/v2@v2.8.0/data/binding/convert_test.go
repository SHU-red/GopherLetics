package binding

import (
	"fmt"
	"strconv"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"fyne.io/fyne/v2/storage"
)

type testItem struct {
	word   string
	number int
}

func testItemFormatter(a testItem) (string, error) {
	return fmt.Sprintf("%s-%d", a.word, a.number), nil
}

func testItemComparator(a, b testItem) bool {
	return a.word == b.word && a.number == b.number
}

func testItemParser(s string) (testItem, error) {
	split := strings.Split(s, "-")
	if len(split) != 2 {
		return testItem{}, fmt.Errorf("invalid split count %d", len(split))
	}

	num, err := strconv.Atoi(split[1])
	if err != nil {
		return testItem{}, fmt.Errorf("error parsing number: %w", err)
	}

	return testItem{split[0], num}, nil
}

func BenchmarkBoolToString(b *testing.B) {
	for i := 0; i < b.N; i++ {
		bo := NewBool()
		s := BoolToString(bo)
		s.Get()

		bo.Set(true)
		s.Get()

		s.Set("trap")
		bo.Get()

		s.Set("false")
		bo.Get()
	}
}

func BenchmarkFloatToString(b *testing.B) {
	for i := 0; i < b.N; i++ {
		f := NewFloat()
		s := FloatToString(f)
		s.Get()

		f.Set(0.3)
		s.Get()

		s.Set("wrong")
		f.Get()

		s.Set("5.00")
		f.Get()
	}
}

func BenchmarkIntToString(b *testing.B) {
	for i := 0; i < b.N; i++ {
		i := NewInt()
		s := IntToString(i)
		s.Get()

		i.Set(3)
		s.Get()

		s.Set("wrong")
		i.Get()

		s.Set("5")
		i.Get()
	}
}

func BenchmarkItemtToString(b *testing.B) {
	for i := 0; i < b.N; i++ {
		i := NewItem(testItemComparator)
		s := ItemToString(i, testItemFormatter, testItemParser, testItemComparator)
		s.Get()

		i.Set(testItem{"test", 2})
		s.Get()

		s.Set("invalid-number")
		i.Get()

		s.Set("a-5")
		i.Get()
	}
}

func BenchmarkStringToBool(b *testing.B) {
	for i := 0; i < b.N; i++ {
		s := NewString()
		b := StringToBool(s)
		b.Get()

		s.Set("true")
		b.Get()

		s.Set("trap") // bug in fmt.SScanf means "wrong" parses as "false"
		b.Get()

		b.Set(false)
		s.Get()
	}
}

func BenchmarkStringToFloat(b *testing.B) {
	for i := 0; i < b.N; i++ {
		s := NewString()
		f := StringToFloat(s)
		f.Get()

		s.Set("3")
		f.Get()

		s.Set("wrong")
		f.Get()

		f.Set(5)
		s.Get()
	}
}

func BenchmarkStringToInt(b *testing.B) {
	for i := 0; i < b.N; i++ {
		s := NewString()
		i := StringToInt(s)
		i.Get()

		s.Set("3")
		i.Get()

		s.Set("wrong")
		i.Get()

		i.Set(5)
		s.Get()
	}
}

func TestBoolToString(t *testing.T) {
	b := NewBool()
	s := BoolToString(b)
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "false", v)

	err = b.Set(true)
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "true", v)

	err = s.Set("trap") // bug in fmt.SScanf means "wrong" parses as "false"
	assert.NotNil(t, err)
	_, err = b.Get()
	assert.Nil(t, err)

	err = s.Set("false")
	assert.Nil(t, err)
	v2, err := b.Get()
	assert.Nil(t, err)
	assert.Equal(t, false, v2)
}

func TestBoolToStringWithFormat(t *testing.T) {
	b := NewBool()
	s := BoolToStringWithFormat(b, "%tly")
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "falsely", v)

	err = b.Set(true)
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "truely", v)

	err = s.Set("true") // valid bool but not valid format
	assert.NotNil(t, err)
	_, err = b.Get()
	assert.Nil(t, err)

	err = s.Set("falsely")
	assert.Nil(t, err)
	v2, err := b.Get()
	assert.Nil(t, err)
	assert.Equal(t, false, v2)
}

func TestFloatToString(t *testing.T) {
	f := NewFloat()
	s := FloatToString(f)
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "0.000000", v)

	err = f.Set(0.3)
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "0.300000", v)

	err = s.Set("wrong")
	assert.NotNil(t, err)
	_, err = f.Get()
	assert.Nil(t, err)

	err = s.Set("5.00")
	assert.Nil(t, err)
	v2, err := f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 5.0, v2)
}

func TestFloatToStringWithFormat(t *testing.T) {
	f := NewFloat()
	s := FloatToStringWithFormat(f, "%.2f%%")
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "0.00%", v)

	err = f.Set(0.3)
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "0.30%", v)

	err = s.Set("4.3") // valid float64 but not valid format
	assert.NotNil(t, err)
	_, err = f.Get()
	assert.Nil(t, err)

	err = s.Set("5.00%")
	assert.Nil(t, err)
	v2, err := f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 5.0, v2)
}

func TestIntToString(t *testing.T) {
	i := NewInt()
	s := IntToString(i)
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "0", v)

	err = i.Set(3)
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "3", v)

	err = s.Set("wrong")
	assert.NotNil(t, err)
	_, err = i.Get()
	assert.Nil(t, err)

	err = s.Set("5")
	assert.Nil(t, err)
	v2, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 5, v2)
}

func TestIntToStringWithFormat(t *testing.T) {
	i := NewInt()
	s := IntToStringWithFormat(i, "num%d")
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "num0", v)

	err = i.Set(3)
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "num3", v)

	err = s.Set("4") // valid int but not valid format
	assert.NotNil(t, err)
	_, err = i.Get()
	assert.Nil(t, err)

	err = s.Set("num5")
	assert.Nil(t, err)
	v2, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 5, v2)
}

func TestStringToBool(t *testing.T) {
	s := NewString()
	b := StringToBool(s)
	v, err := b.Get()
	assert.Nil(t, err)
	assert.Equal(t, false, v)

	err = s.Set("true")
	assert.Nil(t, err)
	v, err = b.Get()
	assert.Nil(t, err)
	assert.Equal(t, true, v)

	err = s.Set("trap") // bug in fmt.SScanf means "wrong" parses as "false"
	assert.Nil(t, err)
	_, err = b.Get()
	assert.NotNil(t, err)

	err = b.Set(false)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "false", v2)
}

func TestStringToBoolWithFormat(t *testing.T) {
	start := "falsely"
	s := BindString(&start)
	b := StringToBoolWithFormat(s, "%tly")
	v, err := b.Get()
	assert.Nil(t, err)
	assert.Equal(t, false, v)

	err = s.Set("truely")
	assert.Nil(t, err)
	v, err = b.Get()
	assert.Nil(t, err)
	assert.Equal(t, true, v)

	err = s.Set("true") // valid bool but not valid format
	assert.Nil(t, err)
	_, err = b.Get()
	assert.NotNil(t, err)

	err = b.Set(false)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "falsely", v2)
}

func TestStringToFloat(t *testing.T) {
	s := NewString()
	f := StringToFloat(s)
	v, err := f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0.0, v)

	err = s.Set("3")
	assert.Nil(t, err)
	v, err = f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 3.0, v)

	err = s.Set("wrong")
	assert.Nil(t, err)
	_, err = f.Get()
	assert.NotNil(t, err)

	err = f.Set(5)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "5.000000", v2)
}

func TestStringToFloatWithFormat(t *testing.T) {
	start := "0.0%"
	s := BindString(&start)
	f := StringToFloatWithFormat(s, "%f%%")
	v, err := f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0.0, v)

	err = s.Set("3.000000%")
	assert.Nil(t, err)
	v, err = f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 3.0, v)

	err = s.Set("4.3") // valid float64 but not valid format
	assert.Nil(t, err)
	_, err = f.Get()
	assert.NotNil(t, err)

	err = f.Set(5)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "5.000000%", v2)
}

func TestStringToInt(t *testing.T) {
	s := NewString()
	i := StringToInt(s)
	v, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0, v)

	err = s.Set("3")
	assert.Nil(t, err)
	v, err = i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 3, v)

	err = s.Set("wrong")
	assert.Nil(t, err)
	_, err = i.Get()
	assert.NotNil(t, err)

	err = i.Set(5)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "5", v2)
}

func TestStringToIntWithFormat(t *testing.T) {
	start := "num0"
	s := BindString(&start)
	i := StringToIntWithFormat(s, "num%d")
	v, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0, v)

	err = s.Set("num3")
	assert.Nil(t, err)
	v, err = i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 3, v)

	err = s.Set("4") // valid int but not valid format
	assert.Nil(t, err)
	_, err = i.Get()
	assert.NotNil(t, err)

	err = i.Set(5)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "num5", v2)
}

func TestStringToURI(t *testing.T) {
	s := NewString()
	u := StringToURI(s)
	v, err := u.Get()
	assert.Nil(t, err)
	assert.Equal(t, nil, v)

	err = s.Set("file:///tmp/test.txt")
	assert.Nil(t, err)
	v, err = u.Get()
	assert.Nil(t, err)
	assert.Equal(t, "file:///tmp/test.txt", v.String())

	// TODO fix issue in URI parser whereby "wrong" is a valid URI
	//err = s.Set("wrong")
	//assert.Nil(t, err)
	//_, err = u.Get()
	//assert.NotNil(t, err)

	uri := storage.NewFileURI("/mydir/")
	err = u.Set(uri)
	assert.Nil(t, err)
	v2, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "file:///mydir/", v2)
}

func TestURIToString(t *testing.T) {
	u := NewURI()
	s := URIToString(u)
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "", v)

	err = u.Set(storage.NewFileURI("/tmp/test.txt"))
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "file:///tmp/test.txt", v)

	// TODO fix issue in URI parser whereby "wrong" is a valid URI
	//err = s.Set("wrong")
	//assert.NotNil(t, err)
	//_, err = u.Get()
	//assert.Nil(t, err)

	err = s.Set("file:///tmp/test.txt")
	assert.Nil(t, err)
	v2, err := u.Get()
	assert.Nil(t, err)
	assert.Equal(t, "file:///tmp/test.txt", v2.String())
}

func TestItemToString(t *testing.T) {
	i := NewItem(testItemComparator)
	s := ItemToString(i, testItemFormatter, testItemParser, testItemComparator)
	v, err := s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "-0", v)

	err = i.Set(testItem{"test", 2})
	assert.Nil(t, err)
	v, err = s.Get()
	assert.Nil(t, err)
	assert.Equal(t, "test-2", v)

	err = s.Set("invalid=-number")
	assert.NotNil(t, err)
	_, err = i.Get()
	assert.Nil(t, err)
	assert.Equal(t, "test-2", v) // Value should not have changed

	err = s.Set("a-5")
	assert.Nil(t, err)
	v2, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, testItem{"a", 5}, v2)
}

func TestFloatToInt(t *testing.T) {
	f := NewFloat()
	i := FloatToInt(f)
	v, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0, v)

	err = f.Set(0.3)
	assert.Nil(t, err)
	v, err = i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0, v)

	err = i.Set(5)
	assert.Nil(t, err)
	v2, err := f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 5.0, v2)
}

func TestIntToFloat(t *testing.T) {
	i := NewInt()
	f := IntToFloat(i)
	v, err := f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 0.0, v)

	err = i.Set(3)
	assert.Nil(t, err)
	v, err = f.Get()
	assert.Nil(t, err)
	assert.Equal(t, 3.0, v)

	err = f.Set(5)
	assert.Nil(t, err)
	v2, err := i.Get()
	assert.Nil(t, err)
	assert.Equal(t, 5, v2)
}

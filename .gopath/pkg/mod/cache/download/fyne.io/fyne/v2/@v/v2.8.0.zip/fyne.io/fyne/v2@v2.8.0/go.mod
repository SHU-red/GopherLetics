module fyne.io/fyne/v2

go 1.22.0

require (
	fyne.io/systray v1.12.2
	github.com/BurntSushi/toml v1.6.0
	github.com/FyshOS/fancyfs v0.0.1
	github.com/anthonynsimon/bild v0.14.0
	github.com/fogleman/gg v1.3.0
	github.com/fredbi/uri v1.1.1
	github.com/fsnotify/fsnotify v1.9.0
	github.com/fyne-io/gl-js v0.2.1-0.20260315212741-029c47fd27e8
	github.com/fyne-io/glfw-js v0.4.0
	github.com/fyne-io/image v0.1.1
	github.com/fyne-io/oksvg v0.2.0
	github.com/go-gl/gl v0.0.0-20260331235117-4566fea9a276
	github.com/go-gl/glfw/v3.4/glfw v0.1.0-pre.1.0.20260707082822-2a407d02d01a
	github.com/go-ole/go-ole v1.3.0
	github.com/go-text/render v0.2.1
	github.com/go-text/typesetting v0.3.4
	github.com/godbus/dbus/v5 v5.2.2
	github.com/hack-pad/go-indexeddb v0.3.2
	github.com/jackmordaunt/icns/v2 v2.2.7
	github.com/jeandeaual/go-locale v0.0.0-20250612000132-0ef82f21eade
	github.com/josephspurrier/goversioninfo v1.7.0
	github.com/lucor/goinfo v0.9.0
	github.com/mattn/go-runewidth v0.0.24
	github.com/mcuadros/go-version v0.0.0-20190830083331-035f6764e8d2
	github.com/natefinch/atomic v1.0.1
	github.com/nfnt/resize v0.0.0-20180221191011-83c6a9932646
	github.com/nicksnyder/go-i18n/v2 v2.5.1
	github.com/rymdport/portal v0.4.2
	github.com/srwiley/rasterx v0.0.0-20220730225603-2ab79fcdd4ef
	github.com/stretchr/testify v1.11.1
	github.com/urfave/cli/v2 v2.27.7
	github.com/yuin/goldmark v1.8.2
	golang.org/x/image v0.24.0
	golang.org/x/mod v0.23.0
	golang.org/x/sys v0.30.0
	golang.org/x/text v0.22.0
	golang.org/x/tools v0.30.0
	golang.org/x/tools/go/vcs v0.1.0-deprecated
)

require (
	github.com/akavel/rsrc v0.10.2 // indirect
	github.com/clipperhouse/uax29/v2 v2.2.0 // indirect
	github.com/cpuguy83/go-md2man/v2 v2.0.7 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/golang/freetype v0.0.0-20170609003504-e2365dfdc4a0 // indirect
	github.com/hack-pad/safejs v0.1.0 // indirect
	github.com/jsummers/gobmp v0.0.0-20230614200233-a9de23ed2e25 // indirect
	github.com/niemeyer/pretty v0.0.0-20200227124842-a10e7caefd8e // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/russross/blackfriday/v2 v2.1.0 // indirect
	github.com/srwiley/oksvg v0.0.0-20221011165216-be6e8873101c // indirect
	github.com/xrash/smetrics v0.0.0-20240521201337-686a1a2994c1 // indirect
	golang.org/x/net v0.35.0 // indirect
	golang.org/x/sync v0.11.0 // indirect
	gopkg.in/check.v1 v1.0.0-20200227125254-8fa46927fb4f // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

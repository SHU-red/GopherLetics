package canvas_test

import (
	"image/color"
	"testing"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/driver/software"
	"fyne.io/fyne/v2/test"

	"github.com/stretchr/testify/assert"
)

func TestRectangle_MinSize(t *testing.T) {
	rect := canvas.NewRectangle(color.Black)
	min := rect.MinSize()

	assert.Positive(t, min.Width)
	assert.Positive(t, min.Height)
}

func TestRectangle_FillColor(t *testing.T) {
	c := color.White
	rect := canvas.NewRectangle(c)

	assert.Equal(t, c, rect.FillColor)
}

func TestRectangle_Radius(t *testing.T) {
	rect := &canvas.Rectangle{
		FillColor:    color.NRGBA{R: 255, G: 200, B: 0, A: 180},
		StrokeColor:  color.NRGBA{R: 255, G: 120, B: 0, A: 255},
		StrokeWidth:  2.0,
		CornerRadius: 12,
	}

	rect.Resize(fyne.NewSize(50, 50))
	test.AssertObjectRendersToMarkup(t, "rounded_rect.xml", rect)

	c := software.NewCanvas()
	c.SetContent(rect)
	c.Resize(fyne.NewSize(60, 60))
	test.AssertRendersToImage(t, "rounded_rect_stroke.png", c)

	rect.StrokeWidth = 0
	test.AssertRendersToImage(t, "rounded_rect.png", c)

	rect.Aspect = 2.0
	test.AssertRendersToImage(t, "rounded_rect_aspect.png", c)
}

func TestRectangle_PerCornerRadius(t *testing.T) {
	rect := &canvas.Rectangle{
		FillColor:               color.NRGBA{R: 255, G: 200, B: 0, A: 180},
		StrokeColor:             color.NRGBA{R: 255, G: 120, B: 0, A: 255},
		StrokeWidth:             2.0,
		CornerRadius:            12,
		TopRightCornerRadius:    2,
		TopLeftCornerRadius:     8,
		BottomLeftCornerRadius:  14,
		BottomRightCornerRadius: 20,
	}

	rect.Resize(fyne.NewSize(50, 50))
	test.AssertObjectRendersToMarkup(t, "rounded_per_corner_rect.xml", rect)

	c := software.NewCanvas()
	c.SetContent(rect)
	c.Resize(fyne.NewSize(60, 60))
	test.AssertRendersToImage(t, "rounded_per_corner_rect_stroke.png", c)

	rect.StrokeWidth = 0
	rect.BottomLeftCornerRadius = 0
	rect.TopRightCornerRadius = 0
	test.AssertRendersToImage(t, "rounded_per_corner_rect.png", c)

	rect.Aspect = 2.0
	rect.CornerRadius = 0
	test.AssertRendersToImage(t, "rounded_per_corner_rect_aspect.png", c)
}

func TestRectangle_RadiusMaximum(t *testing.T) {
	rect := &canvas.Rectangle{
		FillColor:    color.NRGBA{R: 255, G: 200, B: 0, A: 180},
		StrokeColor:  color.NRGBA{R: 255, G: 120, B: 0, A: 255},
		StrokeWidth:  2.0,
		CornerRadius: canvas.RadiusMaximum,
	}

	rect.Resize(fyne.NewSize(80, 50))
	test.AssertObjectRendersToMarkup(t, "maximum_rounded_rect.xml", rect)

	c := software.NewCanvas()
	c.SetContent(rect)
	c.Resize(fyne.NewSize(90, 60))
	test.AssertRendersToImage(t, "maximum_rounded_rect_stroke.png", c)

	rect.StrokeWidth = 0
	test.AssertRendersToImage(t, "maximum_rounded_rect.png", c)

	rect.Aspect = 2.0
	test.AssertRendersToImage(t, "maximum_rounded_rect_aspect.png", c)

	rect.CornerRadius = 3
	rect.Aspect = 0
	rect.BottomLeftCornerRadius = canvas.RadiusMaximum
	rect.BottomRightCornerRadius = canvas.RadiusMaximum
	test.AssertRendersToImage(t, "maximum_rounded_per_corner_rect.png", c)

	rect.Aspect = 3.0
	rect.TopLeftCornerRadius = canvas.RadiusMaximum
	test.AssertRendersToImage(t, "maximum_rounded_per_corner_rect_aspect.png", c)
}

func TestRectangle_shadow(t *testing.T) {
	rect := &canvas.Rectangle{
		FillColor:    color.NRGBA{R: 255, G: 200, B: 0, A: 180},
		StrokeColor:  color.NRGBA{R: 255, G: 120, B: 0, A: 255},
		StrokeWidth:  2.0,
		CornerRadius: 12,
		Shadow: canvas.Shadow{
			Color:      color.White,
			Offset:     fyne.NewPos(-10, -5),
			BlurRadius: 3,
			Variant:    canvas.BoxShadow,
		},
	}

	rect.Resize(fyne.NewSize(50, 50))
	test.AssertObjectRendersToMarkup(t, "rounded_rect_shadow.xml", rect)

	c := software.NewCanvas()
	c.SetContent(rect)
	c.Resize(fyne.NewSize(170, 170))
	rect.Resize(fyne.NewSize(150, 150))
	rect.Move(fyne.NewPos(16, 16))
	test.AssertRendersToImage(t, "rounded_rect_stroke_shadow.png", c)

	rect.StrokeWidth = 0
	rect.Shadow.Variant = canvas.DropShadow
	test.AssertRendersToImage(t, "rounded_rect_shadow.png", c)

	rect.Aspect = 2.0
	rect.CornerRadius = 0
	rect.TopLeftCornerRadius = canvas.RadiusMaximum
	test.AssertRendersToImage(t, "maximum_rounded_per_corner_rect_aspect_shadow.png", c)
}

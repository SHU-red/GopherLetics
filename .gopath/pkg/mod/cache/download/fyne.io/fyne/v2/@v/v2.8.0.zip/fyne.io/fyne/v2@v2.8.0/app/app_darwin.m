//go:build !ci && !wasm && !test_web_driver && !mobile && !tinygo

#import <Foundation/Foundation.h>
#if __MAC_OS_X_VERSION_MAX_ALLOWED >= 101400 || TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR
#import <UserNotifications/UserNotifications.h>
#endif

static int notifyNum = 0;

extern void fallbackSend(char *cTitle, char *cBody);

bool isBundled() {
    return [[NSBundle mainBundle] bundleIdentifier] != nil;
}

#if __MAC_OS_X_VERSION_MAX_ALLOWED >= 101400 || TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR
void doSendNotification(UNUserNotificationCenter *center, NSString *title, NSString *body) {
    UNMutableNotificationContent *content = [UNMutableNotificationContent new];
    [content autorelease];
    content.title = title;
    content.body = body;

    notifyNum++;
    NSString *identifier = [NSString stringWithFormat:@"fyne-notify-%d", notifyNum];
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:identifier
        content:content trigger:nil];

    [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
        if (error != nil) {
            NSLog(@"Could not send notification: %@", error);
        }
    }];
}

void sendNotification(char *cTitle, char *cBody) {
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    NSString *title = [NSString stringWithUTF8String:cTitle];
    NSString *body = [NSString stringWithUTF8String:cBody];

    UNAuthorizationOptions options = UNAuthorizationOptionAlert;
    [center requestAuthorizationWithOptions:options
        completionHandler:^(BOOL granted, NSError *_Nullable error) {
            if (!granted) {
                if (error != NULL) {
                    NSLog(@"Error asking for permission to send notifications %@", error);
                    // this happens if our app was not signed, so do it the old way
                    fallbackSend((char *)[title UTF8String], (char *)[body UTF8String]);
                } else {
                    NSLog(@"Unable to get permission to send notifications");
                }
            } else {
                doSendNotification(center, title, body);
            }
        }];
}

bool scheduleNotification(char *cID, char *cTitle, char *cBody, double seconds) {
    if (seconds <= 0) {
        return false;
    }

    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    NSString *identifier = [NSString stringWithUTF8String:cID];
    NSString *title = [NSString stringWithUTF8String:cTitle];
    NSString *body = [NSString stringWithUTF8String:cBody];

    UNMutableNotificationContent *content = [UNMutableNotificationContent new];
    [content autorelease];
    content.title = title;
    content.body = body;

    UNTimeIntervalNotificationTrigger *trigger =
        [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:seconds repeats:NO];
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:identifier
        content:content trigger:trigger];

    UNAuthorizationOptions options = UNAuthorizationOptionAlert;
    [center requestAuthorizationWithOptions:options
        completionHandler:^(BOOL granted, NSError *_Nullable error) {
            if (!granted) {
                if (error != NULL) {
                    NSLog(@"Error asking for permission to schedule notifications %@", error);
                } else {
                    NSLog(@"Unable to get permission to schedule notifications");
                }
                return;
            }
            [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable err) {
                if (err != nil) {
                    NSLog(@"Could not schedule notification: %@", err);
                }
            }];
        }];
    return true;
}

void cancelScheduledNotification(char *cID) {
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    NSString *identifier = [NSString stringWithUTF8String:cID];
    [center removePendingNotificationRequestsWithIdentifiers:@[identifier]];
}
#else
void sendNotification(char *cTitle, char *cBody) {
	fallbackSend(cTitle, cBody);
}

bool scheduleNotification(char *cID, char *cTitle, char *cBody, double seconds) {
    return false;
}

void cancelScheduledNotification(char *cID) {
}
#endif

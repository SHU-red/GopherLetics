/*
 * Copyright 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <unistd.h>
#include "oboe_flowgraph_FlowGraphNode_android.h"
#include "oboe_flowgraph_MonoToMultiConverter_android.h"

using namespace FLOWGRAPH_OUTER_NAMESPACE::flowgraph;

MonoToMultiConverter::MonoToMultiConverter(int32_t outputChannelCount)
        : input(*this, 1)
        , output(*this, outputChannelCount) {
}

MonoToMultiConverter::~MonoToMultiConverter() { }

int32_t MonoToMultiConverter::onProcess(int32_t numFrames) {
    const float *inputBuffer = input.getBuffer();
    float *outputBuffer = output.getBuffer();
    int32_t channelCount = output.getSamplesPerFrame();
    for (int i = 0; i < numFrames; i++) {
        // read one, write many
        float sample = *inputBuffer++;
        for (int channel = 0; channel < channelCount; channel++) {
            *outputBuffer++ = sample;
        }
    }
    return numFrames;
}

